package rest;

public enum Etat {
    UN, DEUX;
}